import { createClient } from '@supabase/supabase-js';

import type { NodeType, EdgeType } from '../utils/umlConstants';

// Configuración de Supabase
const supabaseUrl = 'https://bwduexqzhjolwfxupvco.supabase.co';
const supabaseKey =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJ3ZHVleHF6aGpvbHdmeHVwdmNvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA5ODc3NzAsImV4cCI6MjA3NjU2Mzc3MH0.WQiWHEYBzsT0LAa5N3quDDiZlYzfOVz7lY86ZF02RjI';
const supabase = createClient(supabaseUrl, supabaseKey);

// Token OpenAI hardcodeado
const OPENAI_TOKEN =
  'COLOCAR_EL_TOKEN_AQUI';

// Configuración de modelos disponibles
const OPENAI_MODELS = {
  'gpt-4o': {
    name: 'gpt-4o',
    quality: 'Máxima',
    promptCost: 0.005, // $5 por 1K tokens
    completionCost: 0.015, // $15 por 1K tokens
    description: 'Mejor calidad visual, más caro',
  },
  'gpt-4-turbo': {
    name: 'gpt-4-turbo',
    quality: 'Muy Alta',
    promptCost: 0.01, // $10 por 1K tokens
    completionCost: 0.03, // $30 por 1K tokens
    description: 'Balance óptimo calidad/precio (RECOMENDADO)',
  },
  'gpt-4o-mini': {
    name: 'gpt-4o-mini',
    quality: 'Buena',
    promptCost: 0.00025, // $0.25 por 1K tokens
    completionCost: 0.001, // $1 por 1K tokens
    description: 'Más económico, menor precisión visual',
  },
} as const;

// Modelo actual en uso
const CURRENT_MODEL = OPENAI_MODELS['gpt-4o-mini'];

// Tipos para el análisis OpenAI
type OpenAIClass = {
  name: string;
  attributes: Array<{
    name: string;
    type: string;
    visibility: 'public' | 'private' | 'protected';
  }>;
};

type OpenAIRelationship = {
  type: 'association' | 'inheritance' | 'composition' | 'aggregation';
  source: string;
  target: string;
  cardinalitySource?: '1' | '*'; // Cardinalidad del origen
  cardinalityTarget?: '1' | '*'; // Cardinalidad del destino
};

type OpenAIResponse = {
  classes: OpenAIClass[];
  relationships: OpenAIRelationship[];
};

type AnalysisResult = {
  success: boolean;
  nodes?: NodeType[];
  edges?: EdgeType[];
  error?: string;
  cost?: number;
};

/**
 * Convierte la respuesta de OpenAI al formato esperado por umlConstants
 */
function convertOpenAIToUMLConstants(openaiData: OpenAIResponse): {
  nodes: NodeType[];
  edges: EdgeType[];
} {
  const nodes: NodeType[] = [];
  const edges: EdgeType[] = [];

  console.log('  Creando nodos...');

  // Crear nodos
  const startX = 100;
  const startY = 100;
  const spacingX = 300;
  const spacingY = 400;
  const cols = 3;

  // Generar timestamp único para evitar colisiones de IDs
  const timestamp = Date.now();
  let nodeCounter = 1;
  let edgeCounter = 1;

  openaiData.classes.forEach((cls, index) => {
    const row = Math.floor(index / cols);
    const col = index % cols;

    const node: NodeType = {
      id: `imported_${timestamp}_n${nodeCounter++}`,
      label: cls.name,
      x: startX + col * spacingX,
      y: startY + row * spacingY,
      // Filtrar atributos 'id' ya que se asumen implícitamente
      attributes: cls.attributes
        .filter(attr => attr.name.toLowerCase() !== 'id')
        .map(attr => ({
          name: attr.name,
          scope: (attr.visibility as 'public' | 'private' | 'protected') || 'private',
          datatype: mapOpenAITypeToUMLType(attr.type || 'String'),
        })),
    };

    // Calcular altura basada en atributos
    const ATTR_HEIGHT = 28;
    const NODE_HEIGHT = 120;
    node.height = NODE_HEIGHT + (node.attributes?.length || 0) * ATTR_HEIGHT;

    nodes.push(node);
    console.log(`📝 Creado nodo: ${cls.name} (ID: ${node.id})`);
  });

  // Crear un mapa de nombres de clases a IDs
  const classNameToId = new Map<string, string>();
  nodes.forEach(node => {
    classNameToId.set(node.label, node.id);
  });

  // FILTRAR RELACIONES DUPLICADAS BIDIRECCIONALES Y CORREGIR DIRECCIONALIDAD
  console.log('🔧 Filtrando relaciones duplicadas y corrigiendo direccionalidad...');
  console.log('📊 CORRECCIONES DE DIRECCIONALIDAD APLICADAS:');
  const uniqueRelationships: any[] = [];
  const seenRelations = new Set<string>();

  for (const rel of openaiData.relationships) {
    // LOGGING ANTES DE CORRECCIÓN
    console.log(`🔍 Procesando: ${rel.source} → ${rel.target} (${rel.type})`);

    // Aplicar corrección semántica de direccionalidad
    const originalRel = { ...rel };
    const correctedRel = correctRelationshipDirection(rel);

    // LOGGING DESPUÉS DE CORRECCIÓN
    if (originalRel.source !== correctedRel.source || originalRel.target !== correctedRel.target) {
      console.log(
        `  🔄 DIRECCIÓN CORREGIDA: ${originalRel.source} → ${originalRel.target} se convirtió en ${correctedRel.source} → ${correctedRel.target}`
      );
      console.log(`  📍 Razón: Alineación con sistema de renderizado EdgeLayer.tsx`);
      console.log(`  🎯 Tipo ${correctedRel.type}: símbolo se renderizará en posición esperada`);
    } else {
      console.log(
        `  ✅ Dirección mantenida: ${correctedRel.source} → ${correctedRel.target} (sin corrección necesaria)`
      );
    }

    // Crear clave normalizada que incluye el tipo para evitar eliminar diferentes tipos de relación entre las mismas clases
    const key1 = `${correctedRel.source}-${correctedRel.target}-${correctedRel.type}`;
    const key2 = `${correctedRel.target}-${correctedRel.source}-${correctedRel.type}`;

    // Si no hemos visto ninguna de las dos direcciones para este tipo específico, agregar la relación
    if (!seenRelations.has(key1) && !seenRelations.has(key2)) {
      uniqueRelationships.push(correctedRel);
      seenRelations.add(key1);
      console.log(
        `   ✅ Relación única agregada: ${correctedRel.source} → ${correctedRel.target} (${correctedRel.type})`
      );
    } else {
      console.log(
        `   ❌ Relación duplicada omitida: ${correctedRel.source} → ${correctedRel.target} (${correctedRel.type})`
      );
    }
  }

  console.log(
    `📊 Relaciones originales: ${openaiData.relationships.length}, únicas: ${uniqueRelationships.length}`
  );

  // ALGORITMO DE INFERENCIA: Detectar relaciones faltantes para tablas intermedias
  console.log('🔧 Verificando relaciones faltantes para tablas intermedias...');

  // Buscar tablas que sigan patrones de entidades intermedias
  const intermediateEntities = openaiData.classes.filter(cls => {
    const name = cls.name.toLowerCase();
    return (
      name.startsWith('detalle') ||
      name.includes('intermedia') ||
      name.includes('relacion') ||
      name.includes('asociacion') ||
      name.includes('inscripcion') ||
      name.includes('union') ||
      name.includes('conexion')
    );
  });

  intermediateEntities.forEach(intermediateEntity => {
    const entityName = intermediateEntity.name;
    console.log(`🔍 Verificando entidad intermedia: ${entityName}...`);

    // Buscar todas las conexiones a esta entidad
    const connectionsToEntity = uniqueRelationships.filter(
      rel => rel.target === entityName || rel.source === entityName
    );

    console.log(`   Conexiones encontradas: ${connectionsToEntity.length}`);
    connectionsToEntity.forEach(conn => {
      console.log(`      ${conn.source} → ${conn.target}`);
    });

    // Si tiene solo 1 conexión, intentar inferir la segunda
    if (connectionsToEntity.length === 1) {
      const existingConnection = connectionsToEntity[0];
      const connectedEntity =
        existingConnection.source === entityName
          ? existingConnection.target
          : existingConnection.source;

      console.log(`   ⚠️ ${entityName} solo tiene 1 conexión con ${connectedEntity}`);

      // INFERENCIA UNIVERSAL: Buscar entidades principales comunes
      let inferredEntity = null;

      // Buscar entidades que podrían ser la segunda conexión
      const commonEntityPatterns = [
        'producto',
        'item',
        'articulo',
        'elemento',
        'objeto',
        'usuario',
        'cliente',
        'persona',
        'agente',
        'servicio',
        'tarea',
        'actividad',
        'operacion',
        'documento',
        'archivo',
        'registro',
        'entrada',
        'categoria',
        'tipo',
        'clase',
        'grupo',
      ];

      // Buscar por patrones comunes en las entidades disponibles
      for (const pattern of commonEntityPatterns) {
        const candidate = openaiData.classes.find(
          cls =>
            cls.name.toLowerCase().includes(pattern) &&
            cls.name !== entityName &&
            cls.name !== connectedEntity
        );

        if (candidate) {
          inferredEntity = candidate.name;
          break;
        }
      }

      // Si no se encontró por patrones, buscar la entidad más mencionada
      if (!inferredEntity) {
        const entityFrequency = new Map<string, number>();
        openaiData.classes.forEach(cls => {
          if (cls.name !== entityName && cls.name !== connectedEntity) {
            entityFrequency.set(cls.name, 0);
          }
        });

        // Contar referencias en otras relaciones
        uniqueRelationships.forEach(rel => {
          if (entityFrequency.has(rel.source)) {
            entityFrequency.set(rel.source, entityFrequency.get(rel.source)! + 1);
          }
          if (entityFrequency.has(rel.target)) {
            entityFrequency.set(rel.target, entityFrequency.get(rel.target)! + 1);
          }
        });

        // Seleccionar la entidad más referenciada
        let maxCount = 0;
        for (const [entity, count] of entityFrequency.entries()) {
          if (count > maxCount) {
            maxCount = count;
            inferredEntity = entity;
          }
        }
      }

      if (inferredEntity && openaiData.classes.some(cls => cls.name === inferredEntity)) {
        // Verificar que no existe ya esta relación
        const relationExists = uniqueRelationships.some(
          rel =>
            (rel.source === inferredEntity && rel.target === entityName) ||
            (rel.source === entityName && rel.target === inferredEntity)
        );

        if (!relationExists) {
          console.log(
            `   ✅ Agregando relación inferida: ${inferredEntity} → ${entityName} (inferencia universal)`
          );
          uniqueRelationships.push({
            type: 'association',
            source: inferredEntity,
            target: entityName,
            cardinalitySource: '1',
            cardinalityTarget: '*',
          });
        }
      } else {
        console.log(`   ⚠️ No se pudo inferir segunda relación para ${entityName}`);
      }
    }
  });

  console.log(`📊 Relaciones después de inferencia: ${uniqueRelationships.length}`);

  // Identificar tablas intermedias/asociativas de manera universal
  const processedRelationships = new Set<string>();

  console.log('🔍 Identificando patrones de relaciones M:N...');

  // ALGORITMO ROBUSTO: Detectar tablas asociativas de manera universal
  nodes.forEach(candidateNode => {
    const candidateName = candidateNode.label;

    // PASO 1: Buscar todas las relaciones conectadas a este candidato (usando relaciones únicas)
    const incomingRels = uniqueRelationships.filter(rel => rel.target === candidateName);
    const outgoingRels = uniqueRelationships.filter(rel => rel.source === candidateName);
    const allConnectedRels = [...incomingRels, ...outgoingRels];

    console.log(`  Analizando candidato: ${candidateName}`);
    console.log(
      `   Relaciones conectadas: ${allConnectedRels.length} (${incomingRels.length} entrantes, ${outgoingRels.length} salientes)`
    );

    // PASO 2: CRITERIO PRINCIPAL - Nombre típico de tabla intermedia
    const isDetalleEntity = candidateName.toLowerCase().startsWith('detalle');
    const isIntermediaEntity = [
      'intermedia',
      'relacion',
      'inscripcion',
      'asociacion',
      'union',
    ].some(word => candidateName.toLowerCase().includes(word));

    // PASO 3: Solo procesar si tiene nombre típico de tabla intermedia
    if (!isDetalleEntity && !isIntermediaEntity) {
      console.log(`   ❌ No es tabla intermedia: "${candidateName}" no tiene patrón típico`);
      return; // Saltar este candidato
    }

    console.log(`   ✅ Candidato válido: "${candidateName}" tiene patrón de tabla intermedia`);

    // PASO 4: Identificar entidades únicas conectadas (no número de relaciones)
    const connectedEntities = new Set<string>();
    allConnectedRels.forEach(rel => {
      if (rel.source === candidateName) {
        connectedEntities.add(rel.target);
      } else {
        connectedEntities.add(rel.source);
      }
    });

    const entityArray = Array.from(connectedEntities);
    console.log(
      `   🎯 Entidades únicas conectadas: ${entityArray.length} (${entityArray.join(', ')})`
    );

    // PASO 5: Debe conectar exactamente 2 entidades principales
    if (entityArray.length !== 2) {
      console.log(
        `   ❌ Rechazado: conecta ${entityArray.length} entidades únicas (debe ser exactamente 2)`
      );
      return;
    }

    const [entityA, entityB] = entityArray;
    console.log(`   🎯 Entidades conectadas: ${entityA} ↔ ${entityB}`);

    // PASO 6: Verificar que las entidades conectadas NO sean tablas intermedias
    const entityAIsIntermediate =
      entityA.toLowerCase().startsWith('detalle') ||
      ['intermedia', 'relacion', 'inscripcion'].some(word => entityA.toLowerCase().includes(word));
    const entityBIsIntermediate =
      entityB.toLowerCase().startsWith('detalle') ||
      ['intermedia', 'relacion', 'inscripcion'].some(word => entityB.toLowerCase().includes(word));

    if (entityAIsIntermediate || entityBIsIntermediate) {
      console.log(`   ❌ Rechazado: una de las entidades conectadas también es intermedia`);
      console.log(`      ${entityA}: ${entityAIsIntermediate ? 'intermedia' : 'principal'}`);
      console.log(`      ${entityB}: ${entityBIsIntermediate ? 'intermedia' : 'principal'}`);
      return;
    }

    // PASO 7: DETECTADA TABLA ASOCIATIVA VÁLIDA
    const entityIdA = classNameToId.get(entityA);
    const entityIdB = classNameToId.get(entityB);

    if (!entityIdA || !entityIdB) {
      console.log(
        `   ❌ Error: IDs no encontrados para ${entityA} (${entityIdA}) o ${entityB} (${entityIdB})`
      );
      return;
    }

    console.log(`🎉 TABLA ASOCIATIVA DETECTADA: ${candidateName}`);
    console.log(`   Conecta: ${entityA} ↔ ${entityB}`);

    // PASO 8: Configurar tabla asociativa (patrón exacto del sistema manual)
    candidateNode.asociativa = true;
    candidateNode.relaciona = [entityIdA, entityIdB];

    // PASO 9: Crear las 2 relaciones M:N (EntidadA → Tabla, EntidadB → Tabla)
    const edgeA = {
      id: `imported_${timestamp}_e${edgeCounter++}`,
      source: entityIdA,
      target: candidateNode.id,
      tipo: 'asociacion' as const,
      multiplicidadOrigen: '1' as const,
      multiplicidadDestino: '*' as const,
    };
    edges.push(edgeA);

    const edgeB = {
      id: `imported_${timestamp}_e${edgeCounter++}`,
      source: entityIdB,
      target: candidateNode.id,
      tipo: 'asociacion' as const,
      multiplicidadOrigen: '1' as const,
      multiplicidadDestino: '*' as const,
    };
    edges.push(edgeB);

    // PASO 10: Marcar relaciones como procesadas
    allConnectedRels.forEach(rel => {
      processedRelationships.add(`${rel.source}-${rel.target}`);
      processedRelationships.add(`${rel.target}-${rel.source}`);
    });

    console.log(`   ✅ Configuración completada:`);
    console.log(`      - Tabla: ${candidateName} (asociativa: true)`);
    console.log(`      - Relaciona: [${entityA}, ${entityB}]`);
    console.log(`      - Edge A: ${entityA} → ${candidateName} (${edgeA.id})`);
    console.log(`      - Edge B: ${entityB} → ${candidateName} (${edgeB.id})`);
    console.log(`      - Total edges: ${edges.length}`);
  });

  console.log('🔗 Procesando relaciones directas...');
  console.log(`📋 Total relaciones únicas para procesar: ${uniqueRelationships.length}`);

  // Crear mapa de entidades conectadas vía M:N para evitar relaciones directas duplicadas
  const mnConnectedEntities = new Set<string>();
  nodes
    .filter(n => n.asociativa && n.relaciona)
    .forEach(tableNode => {
      const [idA, idB] = tableNode.relaciona!;
      const nameA = nodes.find(n => n.id === idA)?.label;
      const nameB = nodes.find(n => n.id === idB)?.label;
      if (nameA && nameB) {
        mnConnectedEntities.add(`${nameA}-${nameB}`);
        mnConnectedEntities.add(`${nameB}-${nameA}`); // Ambas direcciones
        console.log(`📝 M:N registrado: ${nameA} ↔ ${nameB} (evitar relaciones directas)`);
      }
    });

  // Procesar relaciones directas (no M:N)
  uniqueRelationships.forEach((rel, idx) => {
    const relKey = `${rel.source}-${rel.target}`;

    console.log(
      `🔗 Relación ${idx + 1}: ${rel.source} → ${rel.target} (${rel.type}) cardinalidades: origen="${rel.cardinalitySource || 'auto'}", destino="${rel.cardinalityTarget || 'auto'}"`
    );

    if (processedRelationships.has(relKey)) {
      console.log(`  ⏭️ Saltando - ya procesada como M:N: ${relKey}`);
      return;
    }

    // NUEVA VERIFICACIÓN: Evitar relaciones directas entre entidades conectadas vía M:N
    if (mnConnectedEntities.has(`${rel.source}-${rel.target}`)) {
      console.log(`  ⏭️ Saltando - existe relación M:N: ${rel.source} ↔ ${rel.target}`);
      return;
    }

    const sourceId = classNameToId.get(rel.source);
    const targetId = classNameToId.get(rel.target);

    if (!sourceId || !targetId) {
      console.log(
        `  ❌ Error: No se encontraron IDs para ${rel.source} (${sourceId}) → ${rel.target} (${targetId})`
      );
      return;
    }

    // Parsear cardinalidades
    const { origen, destino } = parseCardinalities(rel);

    const edge: EdgeType = {
      id: `imported_${timestamp}_e${edgeCounter++}`,
      source: sourceId,
      target: targetId,
      tipo: mapOpenAIRelationType(rel.type),
      multiplicidadOrigen: origen,
      multiplicidadDestino: destino,
    };

    edges.push(edge);
    console.log(
      `  ✅ Relación directa agregada: ${rel.source} → ${rel.target} (${edge.tipo}) [${origen}:${destino}]`
    );
  });

  console.log(`✅ Conversión completada: ${nodes.length} nodos, ${edges.length} relaciones`);

  // Resumen de detección M:N
  const associativeNodes = nodes.filter(n => n.asociativa);
  console.log(`📊 RESUMEN FINAL:`);
  console.log(`   - Entidades principales: ${nodes.filter(n => !n.asociativa).length}`);
  console.log(`   - Tablas asociativas (M:N): ${associativeNodes.length}`);
  console.log(`   - Relaciones totales: ${edges.length}`);

  if (associativeNodes.length > 0) {
    console.log(`🔗 RELACIONES M:N DETECTADAS:`);
    associativeNodes.forEach(node => {
      const [id1, id2] = node.relaciona || [];
      const name1 = nodes.find(n => n.id === id1)?.label;
      const name2 = nodes.find(n => n.id === id2)?.label;
      console.log(`   - ${name1} ↔ ${name2} vía ${node.label}`);
    });
  }

  console.log('=======================================');

  return { nodes, edges };
}

/**
 * Mapea tipos de OpenAI a tipos UML
 */
function mapOpenAITypeToUMLType(
  openaiType: string
): 'Integer' | 'Float' | 'Boolean' | 'Date' | 'String' {
  const type = openaiType.toLowerCase();

  if (type.includes('int') || type.includes('number') || type === 'long') {
    return 'Integer';
  }
  if (type.includes('float') || type.includes('double') || type.includes('decimal')) {
    return 'Float';
  }
  if (type.includes('bool')) {
    return 'Boolean';
  }
  if (type.includes('date') || type.includes('time')) {
    return 'Date';
  }

  return 'String'; // Por defecto
}

/**
 * Mapea tipos de relación de OpenAI a tipos UML
 */
function mapOpenAIRelationType(
  openaiType: string
): 'asociacion' | 'agregacion' | 'composicion' | 'herencia' | 'dependencia' {
  const type = openaiType.toLowerCase().trim();

  console.log(`🔄 Mapeando tipo de relación: "${openaiType}" → "${type}"`);

  switch (type) {
    case 'inheritance':
    case 'extends':
    case 'inherits':
    case 'generalization':
    case 'is-a':
    case 'generalización':
      console.log(`  → Detectada HERENCIA`);
      return 'herencia';

    case 'composition':
    case 'composite':
    case 'part-of':
    case 'contains':
    case 'composición':
    case 'parte-de':
      console.log(`  → Detectada COMPOSICIÓN`);
      return 'composicion';

    case 'aggregation':
    case 'aggregate':
    case 'has-a':
    case 'whole-part':
    case 'agregación':
    case 'agregacion':
      console.log(`  → Detectada AGREGACIÓN`);
      return 'agregacion';

    case 'dependency':
    case 'depends':
    case 'uses':
    case 'dependencia':
      console.log(`  → Detectada DEPENDENCIA`);
      return 'dependencia';

    case 'association':
    case 'associates':
    case 'relates':
    case 'asociación':
    case 'asociacion':
    default:
      console.log(`  → Detectada ASOCIACIÓN (por defecto)`);
      return 'asociacion';
  }
}

/**
 * Extrae cardinalidades de origen y destino de la respuesta OpenAI
 * Aplica patrones fijos según el tipo de relación (como en umlConstants)
 */
function parseCardinalities(rel: OpenAIRelationship): { origen: '1' | '*'; destino: '1' | '*' } {
  const relationType = rel.type.toLowerCase();

  // Aplicar patrones de cardinalidad según tipo de relación (como en umlConstants)
  switch (relationType) {
    case 'herencia':
    case 'inheritance':
      console.log(`🔢 Herencia detectada: aplicando patrón 1:1`);
      return { origen: '1', destino: '1' };

    case 'agregacion':
    case 'aggregation':
      console.log(`🔢 Agregación detectada: aplicando patrón 1:*`);
      return { origen: '1', destino: '*' };

    case 'composicion':
    case 'composition':
      console.log(`🔢 Composición detectada: aplicando patrón 1:*`);
      return { origen: '1', destino: '*' };

    case 'asociacion':
    case 'association':
    default:
      // Solo para asociaciones usar las cardinalidades detectadas por OpenAI (normalizadas)
      if (rel.cardinalitySource && rel.cardinalityTarget) {
        // Normalizar cardinalidades a formato válido ("1" o "*")
        const normalizedSource = normalizeCardinality(rel.cardinalitySource);
        const normalizedTarget = normalizeCardinality(rel.cardinalityTarget);

        console.log(
          `🔢 Asociación con cardinalidades directas: origen="${rel.cardinalitySource}"→"${normalizedSource}", destino="${rel.cardinalityTarget}"→"${normalizedTarget}"`
        );
        return {
          origen: normalizedSource,
          destino: normalizedTarget,
        };
      }

      // Fallback para asociaciones: 1:1
      console.log(`🔢 Asociación sin cardinalidades detectadas: usando 1:1 por defecto`);
      return { origen: '1', destino: '1' };
  }
}

/**
 * Corrige la direccionalidad de relaciones para alinearla con el sistema de renderizado EdgeLayer.tsx
 * SOLO aplica correcciones a relaciones con símbolos UML (agregación, composición, herencia)
 * Las asociaciones normales se mantienen tal como las reporta OpenAI
 */
function correctRelationshipDirection(rel: OpenAIRelationship): OpenAIRelationship {
  console.log(`🔍 Evaluando relación: ${rel.source} → ${rel.target} (tipo: ${rel.type})`);

  // CORRECCIÓN ESPECÍFICA POR TIPO DE RELACIÓN BASADA EN RENDERIZADO
  const relationType = rel.type.toLowerCase();

  // REGLA UNIVERSAL: Solo corregir relaciones con símbolos UML específicos
  // Las asociaciones (líneas simples) NO requieren corrección direccional

  if (relationType === 'association' || relationType === 'asociacion') {
    console.log(
      `✅ Asociación: manteniendo dirección original ${rel.source} → ${rel.target} (no requiere corrección)`
    );
    return rel;
  }

  if (relationType === 'herencia' || relationType === 'inheritance') {
    // PROBLEMA IDENTIFICADO: OpenAI sistemáticamente reporta herencia al revés
    // OpenAI reporta: C6 → C5, pero triángulo está pegado a C6
    // Sistema espera: C5 → C6 (donde C6 tiene el triángulo en el target)

    console.log(
      `🔄 Herencia: INVIRTIENDO SISTEMÁTICAMENTE ${rel.source} → ${rel.target} → ${rel.target} → ${rel.source}`
    );
    console.log(`   Razón: OpenAI reporta direcciones inversas a nuestro sistema de renderizado`);
    return {
      ...rel,
      source: rel.target,
      target: rel.source,
    };
  }

  if (relationType === 'composicion' || relationType === 'composition') {
    // PROBLEMA IDENTIFICADO: OpenAI sistemáticamente reporta composición al revés
    // OpenAI reporta: C3 → C4, pero rombo negro está pegado a C4
    // Sistema espera: C4 → C3 (donde C4 tiene el rombo en el source)

    console.log(
      `🔄 Composición: INVIRTIENDO SISTEMÁTICAMENTE ${rel.source} → ${rel.target} → ${rel.target} → ${rel.source}`
    );
    console.log(`   Razón: OpenAI reporta direcciones inversas a nuestro sistema de renderizado`);
    return {
      ...rel,
      source: rel.target,
      target: rel.source,
    };
  }

  if (relationType === 'agregacion' || relationType === 'aggregation') {
    // PROBLEMA IDENTIFICADO: OpenAI sistemáticamente reporta agregación al revés
    // OpenAI reporta: C1 → C2, pero rombo blanco está pegado a C2
    // Sistema espera: C2 → C1 (donde C2 tiene el rombo en el source)

    console.log(
      `🔄 Agregación: INVIRTIENDO SISTEMÁTICAMENTE ${rel.source} → ${rel.target} → ${rel.target} → ${rel.source}`
    );
    console.log(`   Razón: OpenAI reporta direcciones inversas a nuestro sistema de renderizado`);
    return {
      ...rel,
      source: rel.target,
      target: rel.source,
    };
  }

  // Si llegamos aquí, es un tipo de relación no reconocido o una asociación que pasó el filtro
  // Mantener dirección original sin aplicar correcciones semánticas
  console.log(`   ➡️ Tipo no reconocido o asociación: manteniendo ${rel.source} → ${rel.target}`);
  return rel;
}

/**
 * Normaliza cardinalidades de OpenAI al formato válido del sistema ("1" o "*")
 */
function normalizeCardinality(cardinality: string): '1' | '*' {
  const normalized = cardinality.toLowerCase().trim();

  // Patrones que representan multiplicidad múltiple ("*")
  if (
    normalized.includes('*') ||
    normalized.includes('many') ||
    normalized.includes('n') ||
    normalized === '0..*' ||
    normalized === '1..*' ||
    normalized.startsWith('0..') ||
    normalized.startsWith('1..')
  ) {
    return '*';
  }

  // Patrones que representan multiplicidad singular ("1")
  if (
    normalized === '1' ||
    normalized === '1..1' ||
    normalized === '0..1' ||
    normalized === '0' ||
    normalized === 'one'
  ) {
    return '1';
  }

  // Por defecto, asumir multiplicidad singular
  console.log(`⚠️ Cardinalidad desconocida "${cardinality}", asumiendo "1"`);
  return '1';
}

/**
 * Extrae número de un nombre de clase (ej: "Clase1" → 1, "Clase4" → 4)
 */
// function extractNumber(className: string): number | null {
//   const match = className.match(/\d+$/);
//   return match ? parseInt(match[0], 10) : null;
// }

/**
 * Sube una imagen a Supabase y retorna la URL pública
 */
async function uploadImageToSupabase(file: File): Promise<string> {
  // Validar archivo
  if (!file.type.startsWith('image/')) {
    throw new Error('Solo se permiten archivos de imagen');
  }

  if (file.size > 5 * 1024 * 1024) {
    throw new Error('El archivo debe ser menor a 5MB');
  }

  // Generar nombre único
  const fileExt = file.name.split('.').pop();
  const fileName = `diagram_${Date.now()}_${Math.random().toString(36).substring(2)}.${fileExt}`;

  console.log(`📤 Subiendo imagen: ${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`);

  // Subir archivo
  const { error } = await supabase.storage.from('imagenes').upload(fileName, file);

  if (error) {
    throw new Error(`Error al subir imagen: ${error.message}`);
  }

  // Obtener URL pública
  const { data: urlData } = supabase.storage.from('imagenes').getPublicUrl(fileName);

  console.log(`✅ Imagen subida exitosamente: ${urlData.publicUrl}`);
  return urlData.publicUrl;
}

/**
 * Analiza una imagen usando OpenAI Vision API
 */
async function analyzeImageWithOpenAI(imageUrl: string): Promise<OpenAIResponse> {
  const prompt = `ANALIZA este diagrama UML y extrae SOLO el JSON. NO agregues explicaciones.

🔍 PASO 1: IDENTIFICAR TIPOS DE RELACIÓN POR SÍMBOLOS VISUALES

⚠️ MÉTODO CRÍTICO DE ANÁLISIS VISUAL (OBLIGATORIO):

PASO A: Localiza CADA línea entre clases
PASO B: Para cada línea, examina AMBOS extremos buscando símbolos
PASO C: Identifica la FORMA GEOMÉTRICA exacta del símbolo

🔸 ASOCIACIÓN = Línea simple ——————— (DEFAULT - MÁS COMÚN)
   - NO hay símbolos en ningún extremo
   - Solo línea recta conectando clases  
   - USAR ESTE TIPO POR DEFECTO si hay cualquier duda
   - Tipo más común en diagramas UML estándar

🔸 HERENCIA = Triángulo VACÍO ◁ (RARO - solo si es OBVIO)
   - FORMA: Triángulo (3 lados formando punta) MUY CLARO
   - INTERIOR: Vacío/transparente (se ve el fondo a través)
   - UBICACIÓN: En un extremo de la línea, INEQUÍVOCAMENTE visible
   - Solo usar si el triángulo es PERFECTAMENTE claro

🔸 AGREGACIÓN = Rombo HUECO ◇ (RARO - solo si es OBVIO)
   - FORMA: Rombo/diamante (4 lados iguales) MUY CLARO
   - INTERIOR: Completamente BLANCO/VACÍO, contorno visible
   - APARIENCIA: "Hueco", "transparente", pero CLARAMENTE un rombo
   - Solo usar si el rombo vacío es PERFECTAMENTE visible

🔸 COMPOSICIÓN = Rombo RELLENO ♦ (RARO - solo si es OBVIO)
   - FORMA: Rombo/diamante (4 lados iguales) MUY CLARO
   - INTERIOR: Completamente NEGRO/PINTADO, muy contrastante
   - APARIENCIA: "Sólido", "relleno", densidad visual MUY alta
   - Solo usar si el rombo relleno es PERFECTAMENTE visible

⚠️ TÉCNICA ESPECÍFICA DE IDENTIFICACIÓN:

Para CADA símbolo encontrado:
1. "¿Es un TRIÁNGULO (3 lados)?" → SI = inheritance
2. "¿Es un ROMBO (4 lados)?" → continúa al paso 3
3. "¿El rombo está VACÍO por dentro?" → SI = aggregation, NO = composition
4. "¿No veo ningún símbolo?" → association

  VERIFICACIÓN OBLIGATORIA:
- Si detectas "composition" → confirma que es un ROMBO NEGRO
- Si detectas "aggregation" → confirma que es un ROMBO BLANCO  
- Si detectas "inheritance" → confirma que es un TRIÁNGULO
- NUNCA confundas triángulos con rombos

🔍 PASO 2: DETECTAR VISIBILIDADES DE ATRIBUTOS

CRÍTICO: Busca símbolos de visibilidad antes del nombre de cada atributo:
- + → "public" (más común en diagramas de clase)
- - → "private" 
- # → "protected"
- Si NO hay símbolo → usar "public" por defecto

🔍 PASO 3: DETECTAR CARDINALIDADES EN AMBOS EXTREMOS

CRÍTICO: Examina cuidadosamente los EXTREMOS de cada línea de relación.
Busca números, símbolos o texto cerca de CADA extremo:

PATRONES VISUALES de cardinalidad a buscar:
- "1" o "1..1" o "0..1" → usar "1" 
- "*" o "0..*" o "1..*" o "many" o "n" → usar "*"

IMPORTANTE: Solo usa estos dos valores exactos en el JSON:
- cardinalitySource: "1" (para relaciones singulares)
- cardinalityTarget: "*" (para relaciones múltiples)
NO uses valores como "0..*", "1..*", "0..1" - conviértelos a "1" o "*"

UBICACIÓN PRECISA de cardinalidades:
- Busca números/símbolos MUY CERCA del punto donde la línea TOCA el borde de cada clase
- ORIGEN (cardinalitySource): número/símbolo junto al extremo donde SALE la línea
- DESTINO (cardinalityTarget): número/símbolo junto al extremo donde LLEGA la línea
- Las cardinalidades suelen estar a 2-5 píxeles del punto de contacto línea-clase

PATRONES VISUALES típicos:
- Cardinalidad en esquina superior/inferior del borde de la clase
- Números pequeños cerca de flechas o extremos de líneas
- Símbolos como * o números como 1, 0..1, 1..* muy próximos al contacto

IMPORTANTE: Si NO encuentras cardinalidades visibles explícitas en el diagrama, usa:
- cardinalitySource: "1" 
- cardinalityTarget: "1"
(Relación 1:1 por defecto - NO asumas multiplicidades específicas)

🔍 PASO 4: DETERMINAR DIRECCIONALIDAD CORRECTA

CRÍTICO: La dirección de la relación debe basarse en la POSICIÓN VISUAL del símbolo, NO en nombres de clases.

Para AGREGACIÓN y COMPOSICIÓN (rombos):
1. Localiza visualmente dónde está el rombo (◇ o ♦)
2. La clase que TIENE el rombo es la clase "todo" (source)
3. La clase SIN rombo es la clase "parte" (target)
4. Relación SIEMPRE va: ClaseConRombo → ClaseSinRombo

Ejemplos visuales:
- Si C1 tiene rombo y conecta con C2 → "source": "C1", "target": "C2"
- Si C3 tiene rombo y conecta con C4 → "source": "C3", "target": "C4"

Para HERENCIA (triángulos):
1. El triángulo apunta HACIA la superclase (clase padre)
2. La relación va: Subclase → Superclase (clase que hereda → clase de la cual hereda)
3. Si C6 tiene flecha con triángulo apuntando a C5 → "source": "C6", "target": "C5"
4. Ejemplo: Auto hereda de Vehiculo → "source": "Auto", "target": "Vehiculo"

⚠️ REGLA CRÍTICA: NUNCA uses numeración de clases para determinar dirección. 
SOLO usa la posición visual del símbolo.

CRÍTICO: Rastrea cada línea desde su origen exacto hasta su destino exacto.
DIRECCIONALIDAD: Siempre reporta relaciones en el orden visual correcto.

MÉTODO de verificación línea por línea:
1. Identifica el PUNTO DE CONTACTO exacto donde nace la línea (borde de qué clase)
2. Sigue la TRAYECTORIA VISUAL completa de la línea hasta su destino
3. Confirma el PUNTO DE LLEGADA exacto (borde de qué clase de destino)
4. DIRECCIONALIDAD: Si hay flecha/símbolos, la relación va HACIA donde apunta
5. Si NO hay flecha, usa el orden visual: clase de arriba/izquierda → clase de abajo/derecha

PATRONES de direccionalidad visual:
- HERENCIA: Flecha con triángulo apunta HACIA la clase padre (superclase)
- COMPOSICIÓN: Rombo NEGRO/RELLENO está en la clase "todo", flecha hacia la clase "parte"  
Analizando la imagen que proporcionaste, puedo identificar lo siguiente:

🔍 CLASES DETECTADAS:
C1 - Atributo: A1 (String)
C2 - Atributo: A2 (Integer)
C3 - Atributo: A3 (Float)
C4 - Atributo: A4 (Boolean)
C5 - Atributo: A5 (Date)
C6 - Atributo: A6 (Int)
🔗 RELACIONES DETECTADAS:
Relación 1: C1 → C2
Símbolo: Rombo blanco/vacío ◇ (solo contorno, interior transparente)
Tipo: AGREGACIÓN
Dirección: C1 → C2 (el rombo está en C1)
Relación 2: C3 → C4
Símbolo: Rombo negro/relleno ♦ (completamente pintado)
Tipo: COMPOSICIÓN
Dirección: C3 → C4 (el rombo está en C3)
Relación 3: C5 → C6
Símbolo: Triángulo vacío ◁ (solo contorno, interior transparente)
Tipo: HERENCIA
Dirección: C5 → C6 (C6 hereda de C5, el triángulo apunta hacia la superclase)
📊 RESUMEN ESPERADO:
Esta imagen es perfecta para probar la detección de símbolos porque muestra claramente:

Un rombo vacío (agregación)
Un rombo relleno (composición)
Un triángulo vacío (herencia)
¿Quieres que probemos importar esta imagen para ver si OpenAI puede detectar correctamente estos tres tipos diferentes de relaciones
- AGREGACIÓN: Rombo BLANCO/VACÍO está en la clase "todo", flecha hacia la clase "parte"
- ASOCIACIÓN: Línea simple, usar posición relativa (arriba/izquierda → abajo/derecha)

🔍 TÉCNICA ESPECÍFICA PARA EXAMINAR ROMBOS:
Al encontrar cualquier rombo:
1. Zoom visual en el área del rombo
2. Observa el contraste: ¿se ve "lleno" o "vacío"?
3. Si el rombo tiene la misma densidad visual que el fondo → AGREGACIÓN (vacío)
4. Si el rombo es visualmente más denso/oscuro que el fondo → COMPOSICIÓN (relleno)
5. En diagramas pequeños, rombos pueden verse ambiguos → DEFAULT a AGREGACIÓN

Para tablas "Detalle*":
- DEBE conectar con exactamente 2 entidades
- Crear 2 relaciones separadas: A→Detalle y B→Detalle

VERIFICACIÓN VISUAL: Si múltiples líneas se cruzan o solapan, 
sigue cada una individualmente desde inicio hasta final.

🔍 PASO 5: FORMATO JSON REQUERIDO

{
  "classes": [
    {
      "name": "NombreClase",
      "attributes": [{"name": "atributo", "type": "String", "visibility": "private"}]
    }
  ],
  "relationships": [
    {
      "type": "association|inheritance|composition|aggregation",
      "source": "ClaseOrigen", 
      "target": "ClaseDestino",
      "cardinalitySource": "1|*",
      "cardinalityTarget": "1|*"
    }
  ]
}

⚠️ VERIFICACIÓN FINAL OBLIGATORIA:
- ¿Detectaste símbolos +, -, # para visibilidades?
- ¿Diferenciaste entre TRIÁNGULOS (inheritance) y ROMBOS (aggregation/composition)?
- ¿Diferenciaste entre rombos VACÍOS (aggregation) vs RELLENOS (composition)?
- ¿Cada relación tiene cardinalitySource Y cardinalityTarget?
- ¿Todas las cardinalidades son exactamente "1" o "*" (no "0..*", "1..*", etc.)?
- ¿Cada "Detalle*" tiene exactamente 2 conexiones?
- ¿Seguiste VISUALMENTE cada línea de inicio a fin sin asumir conexiones?
- ¿Verificaste cardinalidades muy cerca de los puntos de contacto línea-clase?

🔍 VERIFICACIÓN ESPECÍFICA DE SÍMBOLOS:
Para cada relación que NO sea "association", confirma:
1. "¿Veo claramente un símbolo geométrico en la línea?"
2. "¿Es TRIÁNGULO (3 lados) → inheritance?"
3. "¿Es ROMBO VACÍO (4 lados, interior blanco) → aggregation?"  
4. "¿Es ROMBO RELLENO (4 lados, interior negro) → composition?"

🚨 REGLA CRÍTICA PARA DETECCIÓN DE TIPOS:

⚠️ SOLO usar "aggregation", "composition", o "inheritance" si ves CLARAMENTE los símbolos UML específicos
⚠️ Si hay CUALQUIER duda sobre el símbolo → usar "association"
⚠️ NO asumir tipos de relación basándose en nombres de clases o contexto semántico
⚠️ Los diagramas de clases normales usan MAYORMENTE "association" (líneas simples)

🔍 VERIFICACIÓN ULTRA-ESTRICTA OBLIGATORIA:

Antes de asignar cualquier tipo que NO sea "association", pregúntate:
1. "¿Veo un símbolo geométrico CLARO y VISIBLE en la línea?"
2. "¿Puedo describir exactamente su forma y ubicación?"
3. "¿Estoy 100% seguro de que NO es solo una línea simple?"

Si la respuesta a CUALQUIERA de estas preguntas es "NO" → usar "association"

REGLA CONSERVADORA UNIVERSAL: 
- En la mayoría de diagramas UML → 80-90% de relaciones son "association" (líneas simples)
- Solo usar otros tipos si los símbolos UML son INEQUÍVOCAMENTE visibles
- Si todas las relaciones detectadas son del mismo tipo no-association → REVISAR - probablemente sean "association"

DOBLE VERIFICACIÓN VISUAL UNIVERSAL: 
- Si detectas muchas relaciones del mismo tipo no-association → REVISAR cada una individualmente
- Los diagramas UML típicos usan principalmente "association" como tipo base
- Confirma que no confundiste líneas que se cruzan o están muy juntas
- Verifica que cada símbolo especial sea realmente un símbolo y no un artefacto visual

⚠️ RECORDATORIO FINAL ANTES DE RESPONDER:
- ¿Todas mis relaciones son del mismo tipo (aggregation/composition)? → REVISAR - probablemente sean "association"
- ¿Veo realmente símbolos UML claros o solo líneas simples? → Si son líneas simples → "association"
- ¿Estoy siendo CONSERVADOR y usando "association" cuando hay duda? → Debe ser SÍ

RESPONDE SOLO CON EL JSON:`;

  const headers = {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${OPENAI_TOKEN}`,
  };

  const payload = {
    model: CURRENT_MODEL.name,
    messages: [
      {
        role: 'user',
        content: [
          {
            type: 'text',
            text: prompt,
          },
          {
            type: 'image_url',
            image_url: {
              url: imageUrl,
              detail: 'high',
            },
          },
        ],
      },
    ],
    max_tokens: 2000,
    temperature: 0.1,
  };

  console.log(`🤖 Analizando imagen con ${CURRENT_MODEL.name}...`);
  console.log(`📊 Calidad esperada: ${CURRENT_MODEL.quality} - ${CURRENT_MODEL.description}`);

  const response = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: headers,
    body: JSON.stringify(payload),
  });

  if (!response.ok) {
    const errorData = await response
      .json()
      .catch(() => ({ error: { message: 'Error desconocido' } }));
    throw new Error(`Error OpenAI: ${errorData.error?.message || response.statusText}`);
  }

  const result = await response.json();

  // Extraer información de uso
  const usage = result.usage || {};
  const cost =
    ((usage.prompt_tokens || 0) * CURRENT_MODEL.promptCost) / 1000 +
    ((usage.completion_tokens || 0) * CURRENT_MODEL.completionCost) / 1000;

  console.log(`✅ Análisis completado con ${CURRENT_MODEL.name}`);
  console.log(`📊 Calidad: ${CURRENT_MODEL.quality} | ${CURRENT_MODEL.description}`);
  console.log(`💰 Costo estimado: $${cost.toFixed(6)} USD`);
  console.log(
    `🔢 Tokens usados: ${usage.total_tokens || 0} (prompt: ${usage.prompt_tokens || 0}, completion: ${usage.completion_tokens || 0})`
  );

  // Parsear respuesta
  let content = result.choices[0]?.message?.content || '';

  // Limpiar markdown si existe
  if (content.startsWith('```json')) {
    content = content.replace('```json', '').replace('```', '').trim();
  } else if (content.startsWith('```')) {
    content = content.replace('```', '').strip();
  }

  console.log('🔍 RESPUESTA RAW DE OPENAI:');
  console.log('📝 Content length:', content.length);
  console.log('📝 Content preview (first 200 chars):', content.substring(0, 200));
  console.log('📝 Content preview (last 100 chars):', content.substring(content.length - 100));

  try {
    const parsedData = JSON.parse(content);
    console.log('✅ JSON parsing exitoso');

    // Verificar estructura básica
    console.log('🔍 Estructura detectada:');
    console.log(
      `  - classes: ${parsedData.classes ? parsedData.classes.length : 'undefined'} elementos`
    );
    console.log(
      `  - relationships: ${parsedData.relationships ? parsedData.relationships.length : 'undefined'} elementos`
    );

    // 🔍 LOGGING DETALLADO PARA DEBUGGING
    console.log('📊 === RESPUESTA COMPLETA DE OPENAI ===');
    console.log('🏛️ Clases detectadas:');
    parsedData.classes?.forEach((cls: any, index: number) => {
      console.log(`  ${index + 1}. ${cls.name}`);
      console.log(
        `     Atributos: [${cls.attributes?.map((a: any) => `${a.name}:${a.type}(${a.visibility || 'sin-scope'})`).join(', ') || 'ninguno'}]`
      );
    });

    console.log('🔗 Relaciones detectadas:');
    parsedData.relationships?.forEach((rel: any, index: number) => {
      console.log(`  ${index + 1}. ${rel.source} → ${rel.target}`);
      console.log(
        `     Tipo: ${rel.type}, Cardinalidades: origen="${rel.cardinalitySource || 'auto'}", destino="${rel.cardinalityTarget || 'auto'}"`
      );
    });

    // ANÁLISIS DE TIPOS DE RELACIÓN
    console.log('🔍 ANÁLISIS DE TIPOS DE RELACIÓN:');
    const relationshipTypes = new Map<string, number>();
    parsedData.relationships?.forEach((rel: any) => {
      const type = rel.type || 'undefined';
      relationshipTypes.set(type, (relationshipTypes.get(type) || 0) + 1);
    });

    console.log('📊 Distribución de tipos de relación:');
    for (const [type, count] of relationshipTypes.entries()) {
      console.log(`  - ${type}: ${count} relaciones`);
    }

    if (relationshipTypes.size === 1 && relationshipTypes.has('association')) {
      console.log(`  ⚠️ ADVERTENCIA: Solo se detectaron relaciones de asociación.`);
      console.log(
        `     Si el diagrama tiene herencia/composición/agregación, revisar detección visual.`
      );
      console.log(`  💡 SUGERENCIA: Verificar que los símbolos UML sean claramente visibles:`);
      console.log(`     - Triángulos vacíos para herencia`);
      console.log(`     - Rombos rellenos para composición`);
      console.log(`     - Rombos vacíos para agregación`);
      console.log(`  🔄 Considerando upgrade a modelo más potente si persiste el problema.`);
    }

    // Análisis general de relaciones
    console.log('🔍 ANÁLISIS GENERAL DE RELACIONES:');
    console.log(`  Total relaciones detectadas: ${parsedData.relationships?.length || 0}`);
    console.log(`  Total clases detectadas: ${parsedData.classes?.length || 0}`);

    // Verificar patrones M:N universales
    const tablesWithDetalle =
      parsedData.classes?.filter(
        (cls: any) =>
          cls.name.toLowerCase().includes('detalle') ||
          cls.name.toLowerCase().includes('intermedia') ||
          cls.name.toLowerCase().includes('inscripcion')
      ) || [];
    console.log(
      `  Posibles tablas intermedias: ${tablesWithDetalle.map((t: any) => t.name).join(', ') || 'ninguna'}`
    );

    // Verificar conectividad general
    const allClassNames = parsedData.classes?.map((cls: any) => cls.name) || [];
    const connectedClasses = new Set<string>();
    parsedData.relationships?.forEach((rel: any) => {
      connectedClasses.add(rel.source);
      connectedClasses.add(rel.target);
    });
    const unconnectedClasses = allClassNames.filter((name: string) => !connectedClasses.has(name));
    if (unconnectedClasses.length > 0) {
      console.log(`  ⚠️ Clases sin conexiones: ${unconnectedClasses.join(', ')}`);
    }

    // VERIFICACIÓN ESPECÍFICA: Comprobar relaciones esperadas comunes
    const expectedCommonRelations = [
      { actor: 'Cliente', action: 'Venta' },
      { actor: 'Proveedor', action: 'Compra' },
      { classifier: 'Categoria', classified: 'Producto' },
    ];

    expectedCommonRelations.forEach(expected => {
      const hasRelation = parsedData.relationships?.some(
        (rel: any) =>
          (rel.source === expected.actor && rel.target === expected.action) ||
          (rel.source === expected.classifier && rel.target === expected.classified) ||
          (rel.source === expected.action && rel.target === expected.actor) ||
          (rel.source === expected.classified && rel.target === expected.classifier)
      );

      const hasActor = allClassNames.includes(expected.actor || expected.classifier || '');
      const hasAction = allClassNames.includes(expected.action || expected.classified || '');

      if (hasActor && hasAction && !hasRelation) {
        console.log(
          `  🚨 RELACIÓN FALTANTE DETECTADA: ${expected.actor || expected.classifier} ↔ ${expected.action || expected.classified}`
        );
      }
    });

    console.log('📄 JSON completo:', JSON.stringify(parsedData, null, 2));
    console.log('============================================');

    return parsedData;
  } catch (error) {
    console.error('❌ Error parseando JSON:', error);
    console.error('📄 Respuesta recibida:', content);
    throw new Error('La respuesta de OpenAI no es un JSON válido');
  }
}

/**
 * Función principal: importa una imagen, la analiza y retorna nodos/edges
 */
export async function importDiagramFromImage(
  file: File,
  onProgress?: (stage: string) => void
): Promise<AnalysisResult> {
  try {
    // Fase 1: Subir imagen
    onProgress?.('Subiendo imagen a Supabase...');
    const imageUrl = await uploadImageToSupabase(file);

    // Fase 2: Analizar con OpenAI
    onProgress?.('Analizando diagrama con OpenAI...');
    const openaiResponse = await analyzeImageWithOpenAI(imageUrl);

    // Fase 3: Convertir a formato UML
    onProgress?.('Convirtiendo a formato UML...');
    const { nodes, edges } = convertOpenAIToUMLConstants(openaiResponse);

    console.log(`📊 Importación exitosa: ${nodes.length} clases, ${edges.length} relaciones`);

    return {
      success: true,
      nodes,
      edges,
    };
  } catch (error) {
    console.error('❌ Error en importación:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Error desconocido',
    };
  }
}

/**
 * Valida que se tenga un token de OpenAI configurado (legacy, ya no se usa)
 */
export function validateOpenAIToken(token: string): boolean {
  return !!(token && token.startsWith('sk-') && token.length > 20);
}
